<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\CheckReservationStatus::class,
        Commands\SendNotification::class,
        Commands\GenerateReports::class,
        Commands\GenerateHebrewAudios::class,
        Commands\UpdateTTSAudio::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('rs:generate_reports')
            ->monthlyOn(1, '00:00');

        $schedule->command('rs:check_reservation_status')
            ->hourly();

        $schedule->command('rs:send_notifications')
            ->everyMinute();

        /*$schedule->command('hebaudio:generate')
            ->everyMinute();*/
    }

    /**
     * Register the Closure based commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        require base_path('routes/console.php');
    }
}

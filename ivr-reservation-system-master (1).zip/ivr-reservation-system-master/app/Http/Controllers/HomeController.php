<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use SMD\Common\ReservationSystem\Models\RsReservation;

class HomeController extends AppBaseController
{
    public function __construct()
    {
        //$this->middleware(['auth']);
    }

    public function index(Request $request)
    {
        if ($request->user()) {
            $today = new \DateTime();
            $today = $today->format('Y-m-d');

            $reservations = RsReservation::active()
                ->forUser($request->user())
                //->where('date_start', $today)
                ->orderBy('created_at', 'desc');

            return view('home')->with([
                'reservations' => $reservations->get()
            ]);
        }

        return view('no-auth-home');
    }

    public function setting()
    {
        return view('settings');
    }

}